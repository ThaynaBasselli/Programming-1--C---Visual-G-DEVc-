#include <iostream>
#include <locale.h>
#define SENHA 997567466

using namespace std;

	int senhacofre;

int main(){
	
	setlocale(LC_ALL, "");

	cout << "Digite a senha para abrir o Cofre: ";
	cin >> senhacofre;
	
	if (senhacofre == SENHA){
		cout << "Acesso Permitido.";
	}else{
		cout << "Acesso Negado.";
	}
} 
